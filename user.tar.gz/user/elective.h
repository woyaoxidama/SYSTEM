#ifndef ELECTIVE_H
#define ELECTIVE_H

void files1();//录入学生信息子函数（从文件自动录入） 
void filec1();//录入键盘子函数(从文件自动录入)
void cheak();//学生选课子函数(查询可选课程) 
void hcheak();//学生选课子函数（查询已选课程) 
void elective();//学生选课主函数
void intos1();//存储学生信息 

#endif
