#include<stdio.h>
#include"elective.h"
#include<string.h>
#include<stdlib.h>
#include"main.h"

void files1()//录入学生信息子函数（从文件自动录入） 
{
    FILE * fp;
    struct student *p3,*p4;
    int i;
    N2=0;
    if((fp=fopen("./student.txt","r"))==NULL) 
    {
        printf("找不到文件!\n");
        exit(0);
    }
    p3=p4=(struct student*)malloc(sizeof(struct student));
    fscanf(fp,"%d%s%d%d",&p3->num2,p3->name2,&p3->nelen,&p3->nelescore);
    for(i = 0; i < p3->nelen; i++)
    {
        fscanf(fp,"%d",&p3->nelenum[i]);
	}
    head2=NULL;
    while(!feof(fp)) 
    {
        N2=N2+1;
        if(N2==1)
		{
			head2=p3;
		} 
		else
		{
			p4->next=p3;
		} 
        p4=p3;
        p3=(struct student * )malloc(sizeof(struct student));
        fscanf(fp,"%d%s%d%d",&p3->num2,p3->name2,&p3->nelen,&p3->nelescore);
        for(i = 0; i < p3->nelen; i++)
        {
        	fscanf(fp,"%d",&p3->nelenum[i]);
		}
    }
    p4->next=NULL;
    printf("\t\t\t        录 入 成 功 !\n\n");
}

void filec1()//录入键盘子函数(从文件自动录入) 
{
    FILE * fp;
    struct couse *p1,*p2;
    N1=0;
    if((fp=fopen("./class.txt","r"))==NULL) 
    {
        printf("找不到文件!\n");
        return;
    }
    p1=p2=(struct couse*)malloc(sizeof(struct couse));
    fscanf(fp,"%d%s%s%d%d%d%d",&p1->num1,p1->name1,p1->type,&p1->time,&p1->score,&p1->nelepeo,&p1->Melepeo);
    head1=NULL;
    while(!feof(fp)) 
    {
        N1=N1+1;
        if(N1==1)head1=p1; else p2->next=p1;
        p2=p1;
        p1=(struct couse * )malloc(sizeof(struct couse));
        fscanf(fp,"%d%s%s%d%d%d%d",&p1->num1,p1->name1,p1->type,&p1->time,&p1->score,&p1->nelepeo,&p1->Melepeo);
    }
    p2->next=NULL;
    printf("\t\t\t        录 入 成 功 !\n\n");
}


void cheak()//学生选课子函数(查询可选课程) 
{
    char e;
    struct couse * c, *p0;
    struct student * s;
    int num2,i,j=0,t=0, num1;
    printf("\t\t\t     请 输 入 你 的 学 号 :\n");
    scanf("%d",&num2);
    s=head2;
    while(s->num2!=num2 && s->next!=NULL) s=s->next;
    if(s->num2!=num2) 
    {
        printf("\n\n\t\t不存在你的信息,请进入主菜单录入你的信息!\n");
        return;
    }
    c=head1;
    printf("\n\n\t\t学生学号 学生姓名 已选课程数量 已选课程总计学分\n");
    printf("\n\t\t    %d   %8s %8d %13d\n\n",s->num2,s->name2,s->nelen,s->nelescore);
    printf("\t\t\t       你 的 可 选 课 程 :\n");
    printf("\n\t课程编号 课程名称 课程性质 授课学时 学分 课程已选人数 课程人数上限\n");
    while(c!=NULL) 
    {
        for (t=0,i=0;s->nelenum[i]!=0;i++) 
        {
            if(c->num1==s->nelenum[i]) t=1;
        }
        if(t==0 && (c->nelepeo!=c->Melepeo)) 
        {
			printf("\n\t    %d%10s%10s%7d %6d%9d%12d\n\n",c->num1,c->name1,c->type,c->time,c->score,c->nelepeo,c->Melepeo);
            j++;
        }
        c=c->next;
    }
    if(j==0) 
    {
        printf("你已选完所有课程，无法再多选!\n");
        return;
    }
    printf("选课(y/n)?:\n");
    getchar();
    e=getchar();
    i=0;
    while(e=='y') 
    {
        printf("\n\n");
    printf("\n\t\t\t   请 输 入 要 选 课 的 编 号 :\n");
    scanf("%d",&num1);
    p0=head1;
    while(p0->num1!=num1 && p0!=NULL) p0=p0->next;
    if(p0==NULL) 
    {
        printf("\n不存在该课程的信息,请回主菜单录入信息:\n");
        return;
    }
    for (i=0;s->nelenum[i]!=0;i++);
    s->nelenum[i]=num1;
    (s->nelen)++;
    c=head1;
    while(c->num1!=num1) c=c->next;
    (c->nelepeo)++;
    s->nelescore = s->nelescore + c->score;
        printf("继续选课(y/n)?:\n");
        getchar();
        e=getchar();
    }
}


void hcheak()//学生选课子函数（查询已选课程) 
{
    char c;
    struct couse * p0;
    struct student * p;
    int num2,i,f=0,j,num1;
    printf("\t\t\t        请 输 入 学 号 :\n");
    scanf("%d",&num2);
    p=head2;
    while(p->num2!=num2 && p!=NULL) p=p->next;
    if(p==NULL) 
    {
        printf("\n\n\t\t不存在你的信息,请回主菜单录入信息:\n");
        goto end;
    }
    printf("\n\n\t\t学生学号 学生姓名 已选课程数量 已选课程总计学分\n");
    printf("\n\t\t    %d   %8s %8d %13d\n\n",p->num2,p->name2,p->nelen,p->nelescore);
    printf("\n\n\t\t\t\t  已 选 课 程 :\n\n");
    if(p->nelenum[0]==0) 
    {
        printf("\n\n\t\t\t你 还 没 选 课 !\n");
        goto end;
    }
    printf("\n\t课程编号 课程名称 课程性质 授课学时 学分 课程已选人数 课程人数上限\n");
    for (i=0;p->nelenum[i]!=0;i++) 
    {
        p0=head1;
        while(p0->num1!=p->nelenum[i]) p0=p0->next;
        printf("\n\t    %d%10s%10s%7d %6d%9d%12d\n\n",p0->num1,p0->name1,p0->type,p0->time,p0->score,p0->nelepeo,p0->Melepeo);
        f=f+p0->score;
        p->nelescore=f;
    }
    printf("\t\t\t\t   总 学 分 : %d\n\n",f);
    printf("是否进行退课(y/n)?");
    getchar();
    c=getchar();
    while(c=='y') 
    {
        printf("请输入你要退掉的课程编号:\n");
    	scanf("%d",&num1);
    	p0=head1;
    	while(p0->num1!=num1) p0=p0->next;
    	for (i=0;p->nelenum[i]!=num1;i++);
    	for (j=i;p->nelenum[j]!=0;j++) p->nelenum[j]=p->nelenum[j+1];
   	p->nelenum[--j]=0;
    	(p0->nelepeo)--;
    	p->nelescore = p->nelescore - p0->score; 
    	printf("退课成功!\n");
        printf("继续退课(y/n)?");
        getchar();
        c=getchar();
        (p->nelen)--;
    }
    end:;
}


void intos1()//存储学生信息 
{
    FILE *fp;
    struct couse *p1;
    struct student *p2; 
    if((fp=fopen("./student.txt","w"))==NULL) 
    {
        printf("\n保存失败!");
        return;
    }
    p1=head1;
    p2=head2;
    while(p2!=NULL) 
    {
        fprintf(fp,"%d %s %d %d\n",p2->num2,p2->name2,p2->nelen,p2->nelescore);
        int i;
        for(i = 0; i < p2->nelen; i++)
        {
        	fprintf(fp,"%d\t",p2->nelenum[i]);
		}
		fprintf(fp,"\n\n");
        p2=p2->next;
    }
    fclose(fp);
}

void elective()//学生选课主函数 
{
    int i;
    start:
    printf("\t\t *******************$^$*******************\n\n");
    printf("\t\t\t\t 学 生 选 课\n\n");
    printf("\t\t\t     1.查 询 可 选 课 程\n\n");
    printf("\t\t\t     2.查 询 已 选 课 程\n\n");
    printf("\t\t\t     3.存 储 选 课 信 息\n\n");
    printf("\t\t\t       4.返 回 主 菜 单\n\n");
    printf("\t\t\t       请 输 入 (1 ~ 4) :\n\n");
    printf("\t\t *******************$^$*******************\n\n");
    scanf("%d",&i);
    printf("\n\n");
    switch(i) 
    {
        case(1):cheak();
        printf("\n\n");
        goto start;
        break;
        case(2):hcheak();
        printf("\n\n");
        goto start;
        break;
        case(3):intos1();
        printf("\n\n");
        goto start;
        break;
        case(4):
	break;
    }
}
