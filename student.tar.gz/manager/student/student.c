#include<stdio.h>
#include"student.h"
#include<string.h>
#include<stdlib.h>
#include"main.h"

void keyboards()//录入学生信息子函数（从键盘录入） 
{
    int i;
    struct student *p1,*p2;
    N2=0;
    p1=p2=(struct student *)malloc(sizeof(struct student));
    printf("\t\t\t\t学生学号\t学生姓名\n");
    scanf("%d",&p1->num2);
    if(p1->num2 == 0)
    {
    	return;
	}
	if(p1->num2 < 0 || p1->num2 >9999999)
    {
    	printf("请重新录入！\n\n");
    	keyboards();
	}
    scanf("%s",p1->name2);
    p1->nelen=0;
    p1->nelescore=0;
    for (i=0;i<20;i++) p1->nelenum[i]=0;
    head2=NULL;
    while(1) 
    {
        N2=N2+1;
        if(N2==1)head2=p1; else p2->next=p1;
        p2=p1;
        p1=(struct student * )malloc(sizeof(struct student));
        scanf("%d",&p1->num2);
        if(p1->num2 == 0)
    	{
    		break;
		}
    	scanf("%s",p1->name2);
        p1->nelen=0;
        p1->nelescore=0;
        for (i=0;i<20;i++) p1->nelenum[i]=0;
    }
    p2->next=NULL;
    printf("录入成功!\n");
}
void files()//录入学生信息子函数（从文件录入） 
{
    FILE * fp;
    char filepath[20];
    struct student *p3,*p4;
    int i;
    N2=0;
    printf("输入要读入的文件路径:");
    getchar();
    gets(filepath);
    if((fp=fopen(filepath,"r"))==NULL) 
    {
        printf("找不到%s文件!\n",filepath);
        return;
    }
    p3=p4=(struct student*)malloc(sizeof(struct student));
    fscanf(fp,"%d%s%d%d",&p3->num2,p3->name2,&p3->nelen,&p3->nelescore);
    for(i = 0; i < p3->nelen; i++)
    {
        fscanf(fp,"%d",&p3->nelenum[i]);
	}
    head2=NULL;
    while(!feof(fp)) 
    {
        N2=N2+1;
        if(N2==1)
		{
			head2=p3;
		} 
		else
		{
			p4->next=p3;
		} 
        p4=p3;
        p3=(struct student * )malloc(sizeof(struct student));
        fscanf(fp,"%d%s%d%d",&p3->num2,p3->name2,&p3->nelen,&p3->nelescore);
        for(i = 0; i < p3->nelen; i++)
        {
        	fscanf(fp,"%d",&p3->nelenum[i]);
		}
    }
    p4->next=NULL;
    printf("录入成功!\n\n");
}

void inputs()//录入学生信息主函数 
{
    int i;
    printf("\t\t\t      录入学生信息\n");
    printf("\n\t\t\t       1.从 键 盘 录 入\n");
    printf("\n\t\t\t       2.从文件录入\n");
    printf("\n\t\t\t       3.返回主菜单\n");
    printf("\n\t\t\t      请 选 择(1 ~ 3):\n\n");
    printf("\t\t *******************$^$*******************\n\n");
    scanf("%d",&i);
    switch(i) 
    {
        case(1):keyboards();
        break;
        case(2):files();
        break;
        case(3):break;
    }
}



void inserts()//学生信息管理子函数(填加学生信息) 
{
    struct student *p0,*p1,*p2;
    struct student * incouse;
    p1=head2;
incouse=(struct student *)malloc(sizeof(struct student));
            incouse->nelen=0;
            incouse->nelescore=0;
            incouse->nelenum[0]=0;
            printf("\n\n\t\t\t    学生学号  学生姓名 \n");
            scanf("%d%s",&incouse->num2,incouse->name2);
    p0=incouse;
    if(head2==NULL) 
    {
        head2=p0;
        p0->next=NULL;
    } else
    {
        while((p0->num2 > p1->num2) && (p1->next!=NULL)) 
        {
            p2=p1;
            p1=p1->next;
        }
        if(p0->num2 <= p1->num2) 
        {
            if(head2==p1) head2=p0; else p2->next=p0;
            p0->next=p1;
        } else
        {
            p1->next=p0;
            p0->next=NULL;
        }
    }
    N2=N2+1;
    printf("\t\t\t\t增 添 成 功!\n\n");
}

void dels(int num2)//学生信息管理子函数（删除学生信息) 
{
    struct student *p1,*p2;
    struct couse *p;
    p = head1;
    if(head2==NULL) 
    {
        printf("\n没有该学生信息,无法删除!\n");
        return;
    }
    p1=head2;
    while(num2!=p1->num2 && p1->next!=NULL) 
    {
        p2=p1;
        p1=p1->next;
    }
    if(num2==p1->num2) 
    {
        if(p1==head2) head2=p1->next; else p2->next=p1->next;
        printf("已删除该学生信息!\n");
        	int i;
        	for(i = 0; i < p1->nelen; i++)
        	{
        		if(p->num1 == p1->nelenum[i])
        		{
        			(p->nelepeo)--;
					p = p -> next;
				}
			}
			printf("选课人数发生变化!\n");
        N2=N2-1;
    } else printf("无该学号的学生!\n");   
}

void changes(int num2)//学生信息管理子函数（修改学生信息) 
{
	struct student *p1;
    struct couse *p;
    int i;
    start:
    p = head1;
    if(head2==NULL) 
    {
        printf("\n没有该学生信息,无法修改!\n");
        return;
    }
    p1=head2;
    while(num2!=p1->num2 && p1->next!=NULL) 
    {
        p1=p1->next;
    }
    if(num2==p1->num2) 
    {
		printf("\n\n\t\t学生学号 学生姓名 已选课程数量 已选课程总计学分\n");
    	printf("\n\t\t    %d   %8s %8d %13d\n\n",p1->num2,p1->name2,p1->nelen,p1->nelescore);
    	printf("\n\t\t\t       1.修 改 学 生 学 号\n\n");
    	printf("\n\t\t\t       2.修 改 学 生 姓 名\n\n");
    	printf("\n\t\t\t       3.返 回 主 菜 单\n\n");
    	printf("\n\t\t\t       请 输 入 (1 ~ 3):\n\n");
    	scanf("%d", &i);
    	printf("\n\n");
    	switch(i)
    	{
    		case(1):
    			printf("请输入新的学号:");
    			scanf("%d", &p1->num2);
    			num2=p1->num2;
    			printf("学号修改成功！\n\n");
    			goto start;
    			break;
    		case(2):
    			printf("请输入新的姓名:");
    			scanf("%s", p1->name2);
    			printf("姓名修改成功！\n\n");
    			goto start;
    			break;
    		case(3):break; 
		}
		printf("选课状况发生变化!\n");		
    } 
	else printf("无该学号的学生!\n");   
}

void lists()//输出学生信息 (简单)
{
    struct student * p;
    p=head2;
    printf("\n\n\t\t学生学号 学生姓名 已选课程数量 已选课程总计学分\n");
    while(p!=NULL) 
    {
        printf("\n\t\t    %d   %8s %8d %13d\n\n",p->num2,p->name2,p->nelen,p->nelescore);
        p=p->next;
    }
}

void scheak()//输出学生信息（详细) 
{
    char c;
    struct couse * p0;
    struct student * p;
    int num2,i,f=0;
    printf("\t\t\t\t请 输 入 学 号 :\n");
    scanf("%d",&num2);
    p=head2;
    while(p->num2!=num2 && p!=NULL) p=p->next;
    if(p==NULL) 
    {
        printf("不存在该生的信息,请回主菜单录入信息:\n");
        goto end;
    }
    printf("\n\n\t\t学生学号 学生姓名 已选课程数量 已选课程总计学分\n");
    printf("\n\t\t    %d   %8s %8d %13d\n\n",p->num2,p->name2,p->nelen,p->nelescore);
    printf("\t\t\t\t已 选 课 程:\n");
    if(p->nelenum[0]==0) 
    {
        printf("该生尚未选课!\n");
        goto end;
    }
    printf("\n\t课程编号 课程名称 课程性质 授课学时 学分 课程已选人数 课程人数上限\n");
    for (i=0;p->nelenum[i]!=0;i++) 
    {
        p0=head1;
        while(p0->num1!=p->nelenum[i]) p0=p0->next;
        printf("\n\t    %d%10s%10s%7d %6d%9d%12d\n\n",p0->num1,p0->name1,p0->type,p0->time,p0->score,p0->nelepeo,p0->Melepeo);
        f=f+p0->score;
        p->nelescore=f;
    }
    printf("\t\t\t\t总 学 分 :%d\n",f);
    end:;
}

void managements()//学生信息管理主函数 
{
    struct student * incouse;
    int i,num2;
    start:
    printf("\t\t\t      学 生 信 息 管 理\n\n");
    printf("\t\t\t    1.新 增 学 生 信 息\n\n");
    printf("\t\t\t    2.删 除 学 生 信 息\n\n");
    printf("\t\t\t    3.修 改 学 生 信 息\n\n");
    printf("\t\t\t    4.查 看 学 生 信 息\n\n");
    printf("\t\t\t     5.返 回 主 菜 单\n\n");
    printf("\t\t\t      请 选 择(1 ~ 5):\n");
    scanf("%d",&i);
    printf("\n\n");
    switch(i) 
    {
        case(1): 
        {
            inserts();
            printf("\n\n");
            goto start;
            break;
        }
        case(2): 
        {
            printf("请输入要删除学生的学号:\n");
            scanf("%d",&num2);
            dels(num2);
            printf("\n\n");
            goto start;
            break;
        }
        case(3):
		 {
            printf("请输入要修改学生的学号:\n");
            scanf("%d",&num2);
            changes(num2);
            printf("\n\n");
            goto start;
            break;
         }
        case(4):
        {
        	printf("\n\t\t\t\t1.总 体 概 况\n\n");
			printf("\t\t\t\t2.详 细 信 息\n\n");
			printf("\t\t\t       3.返 回 上 一 层\n\n");
			printf("\t\t\t       请 输 入 (1 ~ 3)：\n\n");
			scanf("%d", &i);
			switch(i)
			{
				case(1):
				lists();
				break;	
				case(2):
				scheak();
				break;
				case(3):
				system("clear");
				break;	
			}
			printf("\n\n");
			goto start;
            break;		
		}
        case(5):
		system("clear");
		break;
    }
}


void intos()//存储学生信息 
{
    FILE *fp;
    struct couse *p1;
    struct student *p2; 
    char filepath[30];
    printf("输入学生选课信息要保存的文件路径:");
    getchar();
    gets(filepath);
    if((fp=fopen(filepath,"w"))==NULL) 
    {
        printf("\n保存失败!");
        return;
    }
    p1=head1;
    p2=head2;
    while(p2!=NULL) 
    {
        fprintf(fp,"%d %s %d %d\n",p2->num2,p2->name2,p2->nelen,p2->nelescore);
        int i;
        for(i = 0; i < p2->nelen; i++)
        {
        	fprintf(fp,"%d\t",p2->nelenum[i]);
		}
		fprintf(fp,"\n\n");
        p2=p2->next;
    }
    fclose(fp);
    printf("学生信息已保存在%s中!\n",filepath);
}
