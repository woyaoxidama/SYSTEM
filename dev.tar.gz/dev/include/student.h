#ifndef STUDENT_H
#define STUDENT_H

void keyboards();//录入学生信息子函数（从键盘录入）
void files();//录入学生信息子函数（从文件录入）
void inputs();//录入学生信息主函数 
void inserts();//学生信息管理子函数(填加学生信息) 
void dels(int num2);//学生信息管理子函数（删除学生信息) 
void changes(int num2);//学生信息管理子函数（修改学生信息) 
void lists();//输出学生信息 (简单)
void scheak();//输出学生信息（详细)
void managements();//学生信息管理主函数
void intos();//存储学生信息 

#endif
