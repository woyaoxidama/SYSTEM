#ifndef CLASS_H
#define CLASS_H

void keyboardc();//录入课程子函数(从键盘录入)
void filec();//录入键盘子函数(从文件录入)
void inputc();//录入课程主函数
void insertc();//课程管理子函数(增加课程)
void delc(int num1);//课程管理子函数(删除课程)
void changec(int num1);//课程管理子函数(修改课程)
void listc();//输出课程信息(简单)
void hstudent();//输出课程信息（详细）
void managementc();//课程管理主函数
void intoc();//存储课程信息  
 
#endif
