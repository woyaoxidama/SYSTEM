#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"elective.h"
#include"class.h"
#include"student.h"
#include"main.h"

int main()//主函数 
{
    int i;
    start:
    system("clear");  
    printf("\t\t *******************$^$*******************\n\n");
    printf("\n\t\t\t 欢 迎 使 用 课 程 系 统 !\n");
    printf("\n\t\t\t\t  菜  单 :\n");
    printf("\n\t\t\t   请 选 择 您 的 身 份 :\n");
    printf("\n\t\t\t\t  1.学 生\n");
    printf("\n\t\t\t\t  2.教 师\n");
    printf("\n\t\t\t       3.退 出 系 统\n");
    printf("\n\t\t\t     请 输 入 (1 ~ 3) :\n\n");
    printf("\t\t *******************$^$*******************\n\n");
    scanf("%d", &i);
    printf("\n\n");
    switch(i)
    {
    	case(1):
    		{
    		system("clear");
		files1();
		filec1();
		printf("\t\t *******************$^$*******************\n\n");
    		printf("\t\t\t\t   学 生 ：\n\n");
    		elective();
    		goto start;
            	break;
		}
	case(2):
		{
		start1:
		system("clear");
                printf("\t\t *******************$^$*******************\n\n");
    		printf("\t\t\t\t   教 师 ：\n\n");
    		printf("\t\t\t\t  1. 课 程\n\n");
    		printf("\t\t\t\t  2. 学 生\n\n");
    		printf("\t\t\t      3. 返 回 主 菜 单\n\n");
    		printf("\t\t\t       请 输 入 ( 1~ 3):\n\n");
                printf("\t\t *******************$^$*******************\n\n");
    		scanf("%d", &i);
		printf("\n\n");
    		switch(i)
    		{
    			case(1):
    				{
    				start2:
                                printf("\t\t *******************$^$*******************\n\n");
				printf("\t\t\t\t   教 师 ：\n\n");
				printf("\t\t *******************$^$*******************\n\n");
				printf("\t\t\t     1.课 程 信 息 录 入\n\n");
    			        printf("\t\t\t     2.课 程 信 息 管 理\n\n");
    				printf("\t\t\t     3.课 程 信 息 存 储\n\n");
    				printf("\t\t\t     4.返 回 上 一 菜 单\n\n");
    				printf("\t\t\t       请 输 入 (1 ~ 4):\n\n");
				printf("\t\t *******************$^$*******************\n\n");
    				scanf("%d", &i);
    				switch(i)
    				{
    					case(1):
    						inputc();
						printf("\n\n");
    						goto start2;
    						break;
    				        case(2):
    						managementc();
						printf("\n\n");    						
						goto start2;
    						break;
    					case(3):
    						intoc();
						printf("\n\n");
						goto start2;
    						break;
    					case(4):
    						break;
				}
    				goto start1;
            			break;
				}
				case(2):
					{
					start3:
					printf("\t\t *******************$^$*******************\n\n");
					printf("\t\t\t\t   教 师 ：\n\n");
					printf("\t\t *******************$^$*******************\n\n");
					printf("\t\t\t     1.学 生 信 息 录 入\n\n");
    					printf("\t\t\t     2.学 生 信 息 管 理\n\n");
    					printf("\t\t\t     3.学 生 信 息 存 储\n\n");
    					printf("\t\t\t     4.返 回 上 一 菜 单\n\n");
    					printf("\t\t\t       请 输 入(1 ~ 4):\n\n");
					printf("\t\t *******************$^$*******************\n\n");
    					scanf("%d", &i);
					printf("\n\n");
    					switch(i)
    					{
    						case(1):
    							inputs();
							printf("\n\n");
    							goto start3;
    							break;
    						case(2):
    							managements();
							printf("\n\n");
    							goto start3;
    							break;
    						case(3):
    							intos();
							printf("\n\n");
							goto start3;
    							break;
						case(4):
    						       break;		
					}
    				        goto start1;
            				break;
					}
				case(3):
					{
					system("clear");
            				break;
					}
			}
    			goto start;
    			break;
		        }
	case(3):
		{
                system("clear");
                printf("感谢使用本系统!\n\n再见!\n");
		}
	}
    return(0);
}

